using System.Drawing.Drawing2D;

namespace SecondTask
{
    public partial class Form1 : Form
    {
        private int[] data;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void btnLoadFile_Click(object sender, EventArgs e)
        {
            Files file = new Files();
            var fileData = file.LoadFile();
            int i = 0;
            data = new int[fileData.Count];
            fileData.ForEach(f =>
            {
                if (int.TryParse(f, out int n))
                    data[i++] = Convert.ToInt32(f);
            });
            CalculateAndDrawTriangle();
        }

        private void CalculateAndDrawTriangle()
        {
            int count = 0;
            int n = data.Length;
            for (int i = 0; i < n; i++)
            {
                for (int j = i + 1; j < n; j++)
                {
                    for (int k = j + 1; k < n; k++)
                    {
                        if (data[i] + data[j] > data[k])
                        {
                            DrawTriangle(data[i], data[j], data[k]);
                            count++;
                        }
                        if (data[i] + data[k] > data[j])
                        {
                            DrawTriangle(data[i], data[k], data[j]);
                            count++;
                        }
                        if (data[k] + data[j] > data[i])
                        {
                            DrawTriangle(data[k], data[j], data[i]);
                            count++;
                        }
                    }
                }
            }
            lblResultSummary.Text = count.ToString();
        }
        private void DrawTriangle(int x, int y, int z)
        {
            Random rnd = new Random();
            Color randomColor = Color.FromArgb(rnd.Next(256), rnd.Next(256), rnd.Next(256));
            SolidBrush sb = new SolidBrush(randomColor);
            Graphics gp = panel.CreateGraphics();
            Point[] myPointArray = new Point[] { new Point(x,0), new Point(0, y), new Point(z, panel.Width) };

            var minMaxX = new PointF(
                myPointArray.Min(point => point.X),
                myPointArray.Max(point => point.X)
            );
            var minMaxY = new PointF(
                myPointArray.Min(point => point.Y),
                myPointArray.Max(point => point.Y)
            );
            var minMaxZ = new PointF(
                myPointArray.Min(point => point.Y),
                myPointArray.Max(point => point.Y)
            );
            var normalizedX = (myPointArray[0].X - minMaxX.X) / (minMaxX.Y - minMaxX.X);
            var normalizedY = (myPointArray[1].Y - minMaxY.X) / (minMaxY.Y - minMaxY.X);
            var normalizedZ = (myPointArray[2].Y - minMaxZ.X) / (minMaxZ.Y - minMaxZ.X);
            var posX = (int)(normalizedX * panel.Width);
            var posY = (int)(normalizedY * panel.Height);
            var posZ = (int)(normalizedZ * panel.Height);
            myPointArray = new Point[] { new Point(posX, rnd.Next(0, panel.Height)), new Point(rnd.Next(0, panel.Width), posY), new Point(posZ, rnd.Next(0, panel.Height)) };
            gp.FillPolygon(sb, myPointArray);
        }
    }
}