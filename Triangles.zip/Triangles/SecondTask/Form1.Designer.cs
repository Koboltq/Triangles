﻿namespace SecondTask
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLoadFile = new System.Windows.Forms.Button();
            this.panel = new System.Windows.Forms.Panel();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.lblResultsName = new System.Windows.Forms.Label();
            this.lblResultSummary = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnLoadFile
            // 
            this.btnLoadFile.Location = new System.Drawing.Point(12, 12);
            this.btnLoadFile.Name = "btnLoadFile";
            this.btnLoadFile.Size = new System.Drawing.Size(75, 23);
            this.btnLoadFile.TabIndex = 1;
            this.btnLoadFile.Text = "Load File";
            this.btnLoadFile.UseVisualStyleBackColor = true;
            this.btnLoadFile.Click += new System.EventHandler(this.btnLoadFile_Click);
            // 
            // panel
            // 
            this.panel.Location = new System.Drawing.Point(93, 12);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(150, 150);
            this.panel.TabIndex = 2;
            // 
            // lblResultsName
            // 
            this.lblResultsName.AutoSize = true;
            this.lblResultsName.Location = new System.Drawing.Point(93, 165);
            this.lblResultsName.Name = "lblResultsName";
            this.lblResultsName.Size = new System.Drawing.Size(44, 15);
            this.lblResultsName.TabIndex = 3;
            this.lblResultsName.Text = "Results";
            // 
            // lblResultSummary
            // 
            this.lblResultSummary.AutoSize = true;
            this.lblResultSummary.Location = new System.Drawing.Point(143, 165);
            this.lblResultSummary.Name = "lblResultSummary";
            this.lblResultSummary.Size = new System.Drawing.Size(0, 15);
            this.lblResultSummary.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(266, 183);
            this.Controls.Add(this.lblResultSummary);
            this.Controls.Add(this.lblResultsName);
            this.Controls.Add(this.panel);
            this.Controls.Add(this.btnLoadFile);
            this.MaximumSize = new System.Drawing.Size(1800, 1800);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnLoadFile;
        private Panel panel;
        private ColorDialog colorDialog1;
        private Label lblResultsName;
        private Label lblResultSummary;
    }
}