﻿namespace FirstTask
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLoadFile = new System.Windows.Forms.Button();
            this.rtbDisplayTriangle = new System.Windows.Forms.RichTextBox();
            this.lblResultName = new System.Windows.Forms.Label();
            this.lblResultValue = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnLoadFile
            // 
            this.btnLoadFile.Location = new System.Drawing.Point(26, 18);
            this.btnLoadFile.Name = "btnLoadFile";
            this.btnLoadFile.Size = new System.Drawing.Size(75, 23);
            this.btnLoadFile.TabIndex = 0;
            this.btnLoadFile.Text = "Load File";
            this.btnLoadFile.UseVisualStyleBackColor = true;
            this.btnLoadFile.Click += new System.EventHandler(this.btnLoadFile_Click);
            // 
            // rtbDisplayTriangle
            // 
            this.rtbDisplayTriangle.Location = new System.Drawing.Point(132, 18);
            this.rtbDisplayTriangle.Name = "rtbDisplayTriangle";
            this.rtbDisplayTriangle.Size = new System.Drawing.Size(352, 257);
            this.rtbDisplayTriangle.TabIndex = 1;
            this.rtbDisplayTriangle.Text = "";
            // 
            // lblResultName
            // 
            this.lblResultName.AutoSize = true;
            this.lblResultName.Location = new System.Drawing.Point(131, 286);
            this.lblResultName.Name = "lblResultName";
            this.lblResultName.Size = new System.Drawing.Size(39, 15);
            this.lblResultName.TabIndex = 3;
            this.lblResultName.Text = "Result";
            // 
            // lblResultValue
            // 
            this.lblResultValue.AutoSize = true;
            this.lblResultValue.Location = new System.Drawing.Point(176, 286);
            this.lblResultValue.Name = "lblResultValue";
            this.lblResultValue.Size = new System.Drawing.Size(13, 15);
            this.lblResultValue.TabIndex = 4;
            this.lblResultValue.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(502, 318);
            this.Controls.Add(this.lblResultValue);
            this.Controls.Add(this.lblResultName);
            this.Controls.Add(this.rtbDisplayTriangle);
            this.Controls.Add(this.btnLoadFile);
            this.Name = "Form1";
            this.Text = "First Task";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnLoadFile;
        private RichTextBox rtbDisplayTriangle;
        private Label lblResultName;
        private Label lblResultValue;
    }
}