﻿namespace FirstTask.Tests;

public class Node
{
    public int data;
    public Node left, right;
    public int sum;

    public Node(int item)
    {
        data = item;
        left = right = null;
    }

    public void TreeCalculate(Node node, int sum)
    {
        if (node.left != null)
        {
            sum += node.left.data;
            TreeCalculate(node.left, sum);
            node.left.sum = sum;
            sum -= node.left.data;
        }
        if (node.right != null)
        {
            sum += node.right.data;
            TreeCalculate(node.right, sum);
            node.right.sum = sum;
        }
    }
}

public class BinaryTree
{
    public List<Node> roots = new List<Node>();
}
