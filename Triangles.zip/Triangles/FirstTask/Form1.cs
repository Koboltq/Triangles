using System.Linq;
using System.Text.RegularExpressions;

namespace FirstTask;

public partial class Form1 : Form
{
    private int[][] data;
    public Form1()
    {
        InitializeComponent();
    }

    private void btnLoadFile_Click(object sender, EventArgs e)
    {
        rtbDisplayTriangle.Text = string.Empty;

        Files file = new Files();
        int row = 0;
        var lines = file.LoadFile();
        data = new int[lines.Count][];
        lines.ToList().ForEach(l =>
        {
            var numbers = Regex.Matches(l, @"\d+").Select(m => int.Parse(m.Value)).ToList();
            if (numbers.Any())
            {
                data[row] = new int[numbers.Count];
                for (int i = 0; i <= row; i++)
                {
                    data[row][i] = numbers[i];
                }
                row++;
            }
        });
        DrawTriangle();
        Calculate();
    }

    private void DrawTriangle()
    {
        int i = 0;
        while (i <= data.Length - 1)
        {
            int k = data.Length - 1;
            int h = 0;
            rtbDisplayTriangle.Text += "\n";
            while (k > i)
            {
                rtbDisplayTriangle.Text += "  ";
                k--;
            }
            while (h <= i)
            {
                rtbDisplayTriangle.Text += $" {data[i][h]} ";
                h++;
            }
            i++;
        }
    }

    private void Calculate()
    {
        for (int i = 1; i < data.Length; i++)
        {
            for (int j = 0; j < i; j++)
            {
                data[i][j] += MaxValue(i, j);
            }
        }
        lblResultValue.Text = MaxLastRow();
    }

    private string MaxLastRow()
    {
        return (from m in data
                   select m.Max()).Max().ToString();
    }

    private int MaxValue(int n, int m)
    {
        int maximum = 0;
        if (n > 0 && m > 0)
        {
            if (data[n - 1][m - 1] > data[n - 1][m])
            {
                maximum = data[n - 1][m - 1];
            }
            else
            {
                maximum = data[n - 1][m];
            }
        }
        else if (n == 0)
            maximum = 0;
        else if (n != 0 && m == 0)
        {
            maximum = data[n - 1][m];
        }
        return maximum;
    }
}