﻿namespace FirstTask;

internal class Files
{
    public List<string> LoadFile()
    {
        var fileDialog = new OpenFileDialog();
        fileDialog.Title = "Open Text File";
        fileDialog.Filter = "TXT files|*.txt";
        fileDialog.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;
        if (fileDialog.ShowDialog() == DialogResult.OK)
        {
           return File.ReadLines(fileDialog.FileName).ToList();
        }
        return new List<string>();
    }
}
